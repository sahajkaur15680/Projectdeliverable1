package ca.sheridancollege.project;
/**
 * The class that models your game. You should create a more specific child of this class and instantiate the methods
 * given.
 *
 * @author Dharampreet Singh
 * @author Ravneet Kaur
 * @author Sahajpreet Kaur
 * @author Harshpreet Singh
 * 18 Jan 2020
 */
import java.util.ArrayList;
import java.util.Scanner;

public abstract class Game {
    private final String name;
    private ArrayList<Player> players;
    private Scanner input;

    public Game(String name) {
        this.name = name;
        players = new ArrayList<>();
        input = new Scanner(System.in);
    }


    // Accessor method for name
    public String getName() {
        return name;
    }

    // Accessor method for players
    public ArrayList<Player> getPlayers() {
        return players;
    }

    // Mutator method for players
    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    // Abstract methods to be implemented by subclasses
    public abstract void play();
    public abstract void declareWinner();

    // Method to register a player with the game
    public void registerPlayer() {
        System.out.print("Enter player name: ");
        String playerName = input.nextLine();
        Player player = new UnoPlayer(playerName); // Assuming UnoPlayer is a concrete implementation of Player
        players.add(player);
        System.out.println(playerName + " has been registered with the game.");
    }
}
