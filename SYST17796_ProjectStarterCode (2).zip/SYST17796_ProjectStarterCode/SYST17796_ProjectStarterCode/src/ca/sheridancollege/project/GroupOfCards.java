package ca.sheridancollege.project;

/**
 * The class that models your game. You should create a more specific child of this class and instantiate the methods
 * given.
 *
 * @author Dharampreet Singh
 * @author Ravneet Kaur
 * @author Sahajpreet Kaur
 * @author Harshpreet Singh
 * 18 Jan 2020
 */
import java.util.ArrayList;
import java.util.Collections;

public class GroupOfCards {
    private final ArrayList<Card> cards;

    public GroupOfCards(int size) {
        cards = new ArrayList<>();
    }

    // Accessor method for cards
    public ArrayList<Card> getCards() {
        return cards;
    }

    // Encapsulation maintained for size

    // Method to shuffle the cards
    public void shuffle() {
        Collections.shuffle(cards);
    }
}
